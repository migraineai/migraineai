MigraineAI Export
=================

Files in this archive:
- profile.json: Account-level profile preferences.
- episodes.json: Logged migraine episodes with structured fields.
- audio_clips.json: Voice log metadata, transcripts, and AI analysis payloads.
- metadata.json: Summary metrics and export timestamps.

Need help? Contact support at support@migraine.ai.